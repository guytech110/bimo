import React, { useState } from 'react';
import { ArrowLeft, TrendingUp, TrendingDown, Clock, Zap, DollarSign, Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface ProviderDetailProps {
  providerId: string;
  onBack: () => void;
}

export default function ProviderDetail({ providerId, onBack }: ProviderDetailProps) {
  const [activeTab, setActiveTab] = useState('Overview');

  const providerData = {
    id: 'claude',
    name: 'Claude API',
    logo: 'https://c.animaapp.com/mf9achtzLNLvGx/img/screenshot-2025-08-30-at-9-14-35-pm_1.png',
    connected: true
  };

  const tokensAndCostData = [
    { date: 'Jan 1', tokensIn: 45000, tokensOut: 52000, cost: 42 },
    { date: 'Jan 2', tokensIn: 58000, tokensOut: 65000, cost: 48 },
    { date: 'Jan 3', tokensIn: 48000, tokensOut: 55000, cost: 38 },
    { date: 'Jan 4', tokensIn: 72000, tokensOut: 78000, cost: 58 },
    { date: 'Jan 5', tokensIn: 65000, tokensOut: 72000, cost: 52 },
    { date: 'Jan 6', tokensIn: 82000, tokensOut: 88000, cost: 68 },
    { date: 'Jan 7', tokensIn: 75000, tokensOut: 82000, cost: 62 }
  ];

  const modelSpendData = [
    { name: 'Opus', value: 680, color: '#06b6d4' },
    { name: 'Sonnet', value: 420, color: '#8b5cf6' },
    { name: 'Haiku', value: 180, color: '#14b8a6' }
  ];

  const topPrompts = [
    {
      id: '1',
      description: 'Customer support chat responses...',
      tokens: 45000,
      cost: 42.5
    },
    {
      id: '2',
      description: 'Code generation and review...',
      tokens: 38000,
      cost: 38.2
    },
    {
      id: '3',
      description: 'Document summarization...',
      tokens: 32000,
      cost: 28.6
    },
    {
      id: '4',
      description: 'Email template generation...',
      tokens: 28000,
      cost: 24.8
    }
  ];

  const tabs = ['Overview', 'Usage', 'Models', 'Prompts', 'Recommendations', 'Settings'];

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="flex items-center text-gray-600 hover:text-gray-900 mr-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Providers
          </button>
          <div className="flex items-center">
            <div className="w-8 h-8 mr-3 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
              <img 
                src={providerData.logo} 
                alt={providerData.name}
                className="w-6 h-6 object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  target.parentElement!.innerHTML = `<div class="w-6 h-6 bg-gray-300 rounded flex items-center justify-center text-gray-600 font-semibold text-xs">C</div>`;
                }}
              />
            </div>
            <div className="flex items-center space-x-3">
              <h1 className="text-xl font-semibold text-gray-900">{providerData.name}</h1>
              <div className="flex items-center text-green-600 text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Connected
              </div>
            </div>
          </div>
        </div>
        <div className="text-sm text-gray-600">This Month</div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-lg border shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Tokens In</span>
            <TrendingUp className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">2.4M</div>
          <div className="flex items-center text-sm text-green-600">
            <TrendingUp className="w-3 h-3 mr-1" />
            +12% vs last month
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Tokens Out</span>
            <TrendingUp className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">2.8M</div>
          <div className="flex items-center text-sm text-green-600">
            <TrendingUp className="w-3 h-3 mr-1" />
            +8% vs last month
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Cost (MTD)</span>
            <DollarSign className="w-4 h-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">$1,280</div>
          <div className="flex items-center text-sm text-red-600">
            <TrendingDown className="w-3 h-3 mr-1" />
            -15% vs last month
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Cost per 1K tokens</span>
            <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">$0.24</div>
          <div className="flex items-center text-sm text-green-600">
            <TrendingDown className="w-3 h-3 mr-1" />
            -3% vs last month
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Cache Hit %</span>
            <Zap className="w-4 h-4 text-teal-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">89%</div>
          <div className="flex items-center text-sm text-green-600">
            <TrendingUp className="w-3 h-3 mr-1" />
            +5% vs last month
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Avg Latency</span>
            <Clock className="w-4 h-4 text-gray-500" />
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">420ms</div>
          <div className="flex items-center text-sm text-green-600">
            <TrendingDown className="w-3 h-3 mr-1" />
            -8ms vs last month
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Alert Banner */}
      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
        <div className="flex items-start">
          <div className="w-5 h-5 text-orange-500 mt-0.5 mr-3">
            <svg fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h4 className="font-medium text-orange-800">Token spike detected</h4>
            <p className="text-sm text-orange-700">Usage is 3.2x higher than 30-day average</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tokens & Cost Trends */}
        <div className="lg:col-span-2 bg-white rounded-lg border shadow-sm p-6">
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Tokens & Cost Trends</h3>
            <p className="text-gray-600 text-sm">7-day performance overview</p>
          </div>
          
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={tokensAndCostData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <XAxis 
                  dataKey="date" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#6b7280' }}
                />
                <YAxis 
                  yAxisId="tokens"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#6b7280' }}
                  domain={[0, 100000]}
                  tickFormatter={(value) => `${value / 1000}K`}
                />
                <YAxis 
                  yAxisId="cost"
                  orientation="right"
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 12, fill: '#6b7280' }}
                  domain={[0, 80]}
                />
                <Line 
                  yAxisId="tokens"
                  type="monotone" 
                  dataKey="tokensIn" 
                  stroke="#14b8a6" 
                  strokeWidth={2}
                  dot={{ fill: '#14b8a6', strokeWidth: 2, r: 4 }}
                />
                <Line 
                  yAxisId="tokens"
                  type="monotone" 
                  dataKey="tokensOut" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  dot={{ fill: '#8b5cf6', strokeWidth: 2, r: 4 }}
                />
                <Line 
                  yAxisId="cost"
                  type="monotone" 
                  dataKey="cost" 
                  stroke="#f59e0b" 
                  strokeWidth={2}
                  dot={{ fill: '#f59e0b', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Chart Legend */}
          <div className="flex items-center justify-center space-x-6 mt-4 pt-4 border-t border-gray-100">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-teal-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">Tokens In</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">Tokens Out</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-600">Cost</span>
            </div>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-3 gap-6 mt-6 pt-6 border-t border-gray-100">
            <div className="text-center">
              <div className="text-2xl font-bold text-teal-600 mb-1">2.4M</div>
              <div className="text-sm text-gray-600">Total Tokens In</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600 mb-1">2.8M</div>
              <div className="text-sm text-gray-600">Total Tokens Out</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600 mb-1">$365</div>
              <div className="text-sm text-gray-600">Total Cost</div>
            </div>
          </div>
        </div>

        {/* Cache Hit Rate */}
        <div className="bg-white rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Cache Hit Rate</h3>
          
          <div className="flex items-center justify-center mb-6">
            <div className="relative w-48 h-48">
              <svg className="w-48 h-48 transform -rotate-90" viewBox="0 0 100 100">
                {/* Background circle */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#e5e7eb"
                  strokeWidth="8"
                  fill="none"
                />
                {/* Progress circle */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="#14b8a6"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${89 * 2.51} ${(100 - 89) * 2.51}`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900">89%</div>
                  <div className="text-sm text-gray-600">Cache Hit</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Prompts by Cost */}
        <div className="bg-white rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Prompts by Cost</h3>
          
          <div className="space-y-4">
            {topPrompts.map((prompt) => (
              <div key={prompt.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                <div className="flex-1">
                  <p className="font-medium text-gray-900 mb-1">{prompt.description}</p>
                  <p className="text-sm text-gray-600">{prompt.tokens.toLocaleString()} tokens</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">${prompt.cost}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Spend by Model */}
        <div className="bg-white rounded-lg border shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Spend by Model</h3>
          
          <div className="flex items-center justify-center mb-6">
            <div className="relative w-48 h-48">
              <PieChart width={192} height={192}>
                <Pie
                  data={modelSpendData}
                  cx={96}
                  cy={96}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {modelSpendData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
              
              {/* Labels */}
              <div className="absolute top-4 right-4 text-right">
                <div className="text-sm font-medium text-purple-600">Sonnet: $420</div>
              </div>
              <div className="absolute top-1/2 right-0 text-right">
                <div className="text-sm font-medium text-teal-600">Haiku: $180</div>
              </div>
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-center">
                <div className="text-sm font-medium text-cyan-600">Opus: $680</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
