import React, { useState } from 'react';
import { Search, AlertTriangle, Users, Cloud } from 'lucide-react';

interface ProvidersIndexProps {
  onProviderSelect: (providerId: string) => void;
}

export default function ProvidersIndex({ onProviderSelect }: ProvidersIndexProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const providers = [
    // AI Providers
    {
      id: 'claude',
      name: 'Claude API',
      type: 'AI',
      connected: true,
      logo: 'https://c.animaapp.com/mf9achtzLNLvGx/img/screenshot-2025-08-30-at-9-14-35-pm_1.png',
      metrics: { 
        label: 'Tokens (MTD)', 
        primary: '2.4M tokens', 
        secondary: '89%', 
        cost: null 
      }
    },
    {
      id: 'openai',
      name: 'OpenAI',
      type: 'AI',
      connected: true,
      logo: 'https://c.animaapp.com/mf9achtzLNLvGx/img/screenshot-2025-08-30-at-9-17-36-pm_2.png',
      metrics: { 
        label: 'Tokens (MTD)', 
        primary: '1.8M tokens', 
        secondary: '$240', 
        cost: null 
      }
    },
    {
      id: 'gemini',
      name: 'Google Gemini',
      type: 'AI',
      connected: false,
      logo: '💎', // Using emoji as placeholder for Gemini logo
      metrics: { 
        label: 'Not Connected', 
        primary: 'Connect to view metrics', 
        secondary: null, 
        cost: null 
      }
    },
    // Cloud Providers
    {
      id: 'aws',
      name: 'AWS',
      type: 'Cloud',
      connected: true,
      logo: 'https://c.animaapp.com/mf9achtzLNLvGx/img/screenshot-2025-08-30-at-9-15-53-pm_1.png',
      metrics: { 
        label: 'Cost (MTD)', 
        primary: '$1,840', 
        secondary: 'EC2', 
        cost: null 
      }
    },
    {
      id: 'gcp',
      name: 'Google Cloud',
      type: 'Cloud',
      connected: false,
      logo: '🌥️', // Using emoji as placeholder for GCP logo
      metrics: { 
        label: 'Not Connected', 
        primary: 'Connect to view metrics', 
        secondary: null, 
        cost: null 
      }
    },
    {
      id: 'azure',
      name: 'Microsoft Azure',
      type: 'Cloud',
      connected: false,
      logo: '🔷', // Using emoji as placeholder for Azure logo
      metrics: { 
        label: 'Not Connected', 
        primary: 'Connect to view metrics', 
        secondary: null, 
        cost: null 
      }
    },
    // SaaS Providers
    {
      id: 'zoom',
      name: 'Zoom',
      type: 'SaaS',
      connected: true,
      logo: 'https://c.animaapp.com/mf9achtzLNLvGx/img/screenshot-2025-08-30-at-9-06-04-pm_2.png',
      metrics: { 
        label: 'Licenses', 
        primary: '45/50', 
        secondary: '90%', 
        cost: null 
      }
    },
    {
      id: 'slack',
      name: 'Slack',
      type: 'SaaS',
      connected: true,
      logo: 'https://c.animaapp.com/mf9achtzLNLvGx/img/screenshot-2025-08-30-at-9-18-01-pm.png',
      metrics: { 
        label: 'Licenses', 
        primary: '32/40', 
        secondary: '80%', 
        cost: null 
      }
    }
  ];

  const filteredProviders = providers.filter(provider => {
    const matchesSearch = provider.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || provider.type === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getConnectionStatus = (connected: boolean) => {
    if (connected) {
      return (
        <div className="flex items-center text-green-600 text-sm">
          <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
          Connected
        </div>
      );
    }
    return (
      <div className="flex items-center text-gray-500 text-sm">
        <AlertTriangle className="w-3 h-3 mr-1" />
        Not Connected
      </div>
    );
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Cloud':
        return <Cloud className="w-4 h-4 text-gray-500" />;
      case 'SaaS':
        return <Users className="w-4 h-4 text-gray-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Providers</h1>
          <p className="text-gray-600">Manage and monitor your connected service providers</p>
        </div>
        <button className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 font-medium">
          Connect Provider
        </button>
      </div>

      {/* Filter Tabs and Search */}
      <div className="flex items-center justify-between">
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
          {['All', 'AI', 'Cloud', 'SaaS'].map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search providers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white"
          />
        </div>
      </div>

      {/* Providers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {filteredProviders.map((provider) => (
          <div key={provider.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow">
            {/* Provider Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div className="w-12 h-12 mr-3 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center">
                  {provider.logo.startsWith('http') ? (
                    <img 
                      src={provider.logo} 
                      alt={provider.name}
                      className="w-10 h-10 object-contain"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                        target.parentElement!.innerHTML = `<div class="w-10 h-10 bg-gray-300 rounded flex items-center justify-center text-gray-600 font-semibold">${provider.name.charAt(0)}</div>`;
                      }}
                    />
                  ) : (
                    <div className="text-2xl">{provider.logo}</div>
                  )}
                </div>
                <div>
                  <div className="flex items-center">
                    <h3 className="font-semibold text-gray-900 mr-2">{provider.name}</h3>
                    {provider.type !== 'AI' && getTypeIcon(provider.type)}
                  </div>
                  <p className="text-sm text-gray-500">{provider.type}</p>
                </div>
              </div>
              {getConnectionStatus(provider.connected)}
            </div>

            {/* Metrics */}
            <div className="mb-6">
              <p className="text-sm text-gray-600 mb-1">{provider.metrics.label}</p>
              <div className="flex items-baseline">
                <span className="text-lg font-semibold text-gray-900">
                  {provider.metrics.primary}
                </span>
                {provider.metrics.secondary && (
                  <span className="text-lg font-semibold text-gray-900 ml-1">
                    • {provider.metrics.secondary}
                  </span>
                )}
              </div>
            </div>

            {/* Action Button */}
            <button
              onClick={() => {
                if (provider.connected) {
                  onProviderSelect(provider.id);
                } else {
                  // Handle connect logic
                  console.log('Connect provider:', provider.id);
                }
              }}
              className={`w-full py-2.5 px-4 rounded-lg font-medium transition-colors ${
                provider.connected
                  ? 'bg-gray-900 text-white hover:bg-gray-800'
                  : 'bg-gray-900 text-white hover:bg-gray-800'
              }`}
            >
              {provider.connected ? 'View Details' : 'Connect'}
            </button>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredProviders.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No providers found</h3>
          <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
        </div>
      )}
    </div>
  );
}
